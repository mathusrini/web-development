import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>Javascript and react.js</h1>
      <p>Basic web development react js bootcamp</p>
    </div>
  );
}

export default Info;
